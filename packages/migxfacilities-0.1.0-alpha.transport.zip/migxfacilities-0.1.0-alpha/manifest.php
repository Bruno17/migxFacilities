<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => false,
    'changelog' => false,
    'setup-options' => 
    array (
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '20b06a77a49e4fbc7b24d66dce3267fa',
      'native_key' => 'migxfacilities',
      'filename' => 'modNamespace/5f01a27d377d6e80428c3c36268e5fe0.vehicle',
      'namespace' => 'migxfacilities',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '3b09b19fdd39bc638191be87f2cf4fc8',
      'native_key' => 1,
      'filename' => 'modCategory/20d74c9944c9bb59d855c655c2386ef6.vehicle',
      'namespace' => 'migxfacilities',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c0958a187b50c857431c98e87db2a9c7',
      'native_key' => 'Facilities',
      'filename' => 'modMenu/1e80b0799c1177a6d16213012cdaf321.vehicle',
      'namespace' => 'migxfacilities',
    ),
  ),
);