<?php
class mfFacility extends xPDOSimpleObject {}