<?php
require_once (dirname(dirname(__FILE__)) . '/mffacility.class.php');
class mfFacility_mysql extends mfFacility {}