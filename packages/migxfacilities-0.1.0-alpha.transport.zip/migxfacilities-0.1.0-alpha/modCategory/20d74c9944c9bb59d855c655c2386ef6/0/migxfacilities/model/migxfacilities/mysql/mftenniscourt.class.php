<?php
require_once (dirname(dirname(__FILE__)) . '/mftenniscourt.class.php');
class mfTennisCourt_mysql extends mfTennisCourt {}