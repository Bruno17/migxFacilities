<?php
class facilityResource extends modResource {}