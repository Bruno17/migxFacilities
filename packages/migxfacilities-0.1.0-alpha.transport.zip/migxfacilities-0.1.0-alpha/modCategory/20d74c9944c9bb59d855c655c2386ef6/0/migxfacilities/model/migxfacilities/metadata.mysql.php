<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'facilityResource',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'mfFacility',
    1 => 'mfTennisCourt',
    2 => 'mfSwimmingPool',
  ),
);