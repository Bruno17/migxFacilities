<?php
class mfTennisCourt extends xPDOSimpleObject {}