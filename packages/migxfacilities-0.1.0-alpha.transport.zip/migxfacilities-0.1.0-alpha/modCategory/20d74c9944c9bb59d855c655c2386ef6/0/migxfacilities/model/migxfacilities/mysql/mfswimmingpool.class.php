<?php
require_once (dirname(dirname(__FILE__)) . '/mfswimmingpool.class.php');
class mfSwimmingPool_mysql extends mfSwimmingPool {}