<?php
require_once (dirname(dirname(__FILE__)) . '/facilityresource.class.php');
class facilityResource_mysql extends facilityResource {}