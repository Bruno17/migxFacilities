<?php
class mfSwimmingPool extends xPDOSimpleObject {}